//
//  Code_HistoryApp.swift
//  Code History
//
//  Created by Matthew Jovenal on 3/31/21.
//

import SwiftUI

@main
struct Code_HistoryApp: App {
    var body: some Scene {
        WindowGroup {
            WelcomeView()
        }
    }
}
